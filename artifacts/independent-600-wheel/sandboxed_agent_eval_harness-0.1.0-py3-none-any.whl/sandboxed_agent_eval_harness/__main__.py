from sandboxed_agent_eval_harness.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
